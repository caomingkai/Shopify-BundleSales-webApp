<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at: 9/9/16 9:59 PM UTC+06:00
 */

namespace PHPShopify;


class ApplicationChargeTest extends TestSimpleResource
{
}