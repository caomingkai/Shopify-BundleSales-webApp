<?php
  // MUST be the very first thing in your document. Before any HTML tags.
  session_start();
?>

<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html>
    <head>
        <title> php-shopify </title>
    </head>
    <body>
        <h1>
            TEST FOR SHOPIFY WITH PHP
        </h1>

<?php

    require_once __DIR__ . '/vendor/autoload.php';

    $config = array(
          'ShopUrl' => $_SESSION["shopUrl"],
          'AccessToken' => $_SESSION["accessToken"],
    );
    var_dump($config);

    PHPShopify\ShopifySDK::config($config);
    echo '<p> this indicate the method has been executed </p>'."\n";

    // Get the ShopifySDK Object
    $shopify = new PHPShopify\ShopifySDK;
        echo '<p> $shopify below : </p>' .  "\n";
        var_dump($shopify);
        echo '<p> ------------------------  </p>' .  "\n";

    // Get all product list (GET request)
    $products = $shopify->Product->get();
        echo '<p> $products below : </p>' . "\n";
        var_dump($products);
        echo '<p> ------------------------  </p>' .  "\n";


?>

        <h1>
            This is bottom
        </h1>
    </body>
</html>
