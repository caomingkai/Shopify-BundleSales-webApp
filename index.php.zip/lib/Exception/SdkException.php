<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at 8/19/16 10:29 AM UTC+06:00
 */

namespace PHPShopify\Exception;


class SdkException extends \Exception
{

}