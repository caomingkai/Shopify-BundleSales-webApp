<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at 8/19/16 10:26 AM UTC+06:00
 */

namespace PHPShopify\Exception;


class CurlException extends \Exception
{

}