<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at 8/19/16 10:28 AM UTC+06:00
 */

namespace PHPShopify\Exception;


class ApiException extends \Exception
{

}