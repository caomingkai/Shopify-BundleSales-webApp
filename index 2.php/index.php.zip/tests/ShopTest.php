<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at: 9/10/16 10:50 AM UTC+06:00
 */

namespace PHPShopify;


class ShopTest extends TestSimpleResource
{

}