<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at: 9/10/16 10:49 AM UTC+06:00
 */

namespace PHPShopify;


class RedirectTest extends TestSimpleResource
{
    /**
     * @inheritDoc
     */
    public $postArray = array(
        "path" => "http://www.apple.com/forums",
        "target" => "http://forums.apple.com",
    );

    /**
     * @inheritDoc
     */
    public $putArray = array(
        "path" => "/tiger",
    );
}