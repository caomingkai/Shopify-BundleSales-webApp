<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at: 9/10/16 10:48 AM UTC+06:00
 */

namespace PHPShopify;


class LocationTest extends TestSimpleResource
{

}