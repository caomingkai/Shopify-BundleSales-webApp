<?php
/**
 * Created by PhpStorm.
 * @author Tareq Mahmood <tareqtms@yahoo.com>
 * Created at: 9/9/16 7:41 PM UTC+06:00
 */

namespace PHPShopify;


class AbandonedCheckoutTest extends TestSimpleResource
{
}